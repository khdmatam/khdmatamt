
import { Component, ChangeDetectionStrategy, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SERVICES_DATA, ServiceCategory } from './services-data';

export interface Testimonial {
  name: string;
  city: string;
  rating: number;
  review: string;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [],
  // FIX: Corrected typo from `Change-DetectionStrategy` to `ChangeDetectionStrategy`.
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [CommonModule],
})
export class AppComponent {
  readonly serviceCategories = signal<ServiceCategory[]>(SERVICES_DATA);
  readonly whatsAppNumber = '966590017101';
  readonly baseWhatsAppUrl = `https://wa.me/${this.whatsAppNumber}`;
  readonly currentYear = new Date().getFullYear();

  searchTerm = signal('');

  readonly testimonials = signal<Testimonial[]>([
    {
      name: 'فهد المطيري',
      city: 'الرياض',
      rating: 5,
      review: 'رسوم رخص العمل كانت مرتفعة جدًا، وفريق "خدمتك أولويتي" ساعدني في الحصول على إعفاء للمنشأة. جددت لعمالي بـ 100 ريال فقط. شكرًا لجهودكم.'
    },
    {
      name: 'عبدالله محمد',
      city: 'جدة',
      rating: 5,
      review: 'كان كفيلي السابق يرفض نقل كفالتي، وساعدني فريق "خدمتك أولويتي" على إتمام النقل بنجاح. أشكركم جزيل الشكر على مصداقيتكم.'
    },
    {
      name: 'نورة القحطاني',
      city: 'الدمام',
      rating: 5,
      review: 'كنت بحاجة لإصدار سجل تجاري وبدء مشروعي الخاص. قاموا بإنهاء كافة الإجراءات في وقت قياسي وباحترافية عالية. خدمة رائعة بالفعل.'
    },
    {
      name: 'سيد خان',
      city: 'المدينة المنورة',
      rating: 5,
      review: 'خدمة ممتازة وسريعة! ساعدوني في الحصول على الكشف الطبي اللازم لإصدار إقامتي دون أي تعقيدات. أنصح بهم بشدة.'
    },
     {
      name: 'صالح الغامدي',
      city: 'مكة المكرمة',
      rating: 5,
      review: 'أكثر خدمة احترافية تعاملت معها. ساعدوني في تصديق العقود من الغرفة التجارية بسرعة. تواصلهم واضح ومتوفرون دائمًا.'
    },
    {
      name: 'فاطمة أحمد',
      city: 'أبها',
      rating: 5,
      review: 'واجهت صعوبة في تجديد إقامات أبنائي بعد وفاة زوجي. الفريق تعامل مع الموضوع باحترافية وتعاطف كبير. أنا ممتنة جدًا لهم.'
    },
    {
      name: 'عائشة العتيبي',
      city: 'حائل',
      rating: 5,
      review: 'كان لدي تأشيرة خروج نهائي طارئة وتحتاج إلى إلغاء. لقد تعاملوا معها بسرعة لا تصدق وأنقذوني من موقف صعب. لا أستطيع أن أوفيهم حقهم من الشكر.'
    },
    {
      name: 'مريم إبراهيم',
      city: 'تبوك',
      rating: 4,
      review: 'ساعدوني في حل مشكلة متعلقة بنظام حماية الأجور. كان الفريق على دراية كبيرة بالأنظمة وتابعوا معي حتى تم حل المشكلة. شكرًا لكم.'
    }
  ]);

  readonly filteredServiceCategories = computed(() => {
    const term = this.searchTerm().toLowerCase().trim();
    if (!term) {
      return this.serviceCategories();
    }

    return this.serviceCategories()
      .map(category => {
        const filteredServices = category.services.filter(
          service =>
            service.name.toLowerCase().includes(term) ||
            service.description.toLowerCase().includes(term)
        );
        return { ...category, services: filteredServices };
      })
      .filter(category => category.services.length > 0);
  });

  readonly generalWhatsAppLink = computed(() => {
    const message = `مرحبًا، أرغب في الاستفسار عن خدماتكم بشكل عام.`;
    return `${this.baseWhatsAppUrl}?text=${encodeURIComponent(message)}`;
  });

  generateWhatsAppLink(serviceName: string): string {
    const message = `مرحبًا، أرغب بالاستفسار عن خدمة: ${serviceName}`;
    return `${this.baseWhatsAppUrl}?text=${encodeURIComponent(message)}`;
  }

  scrollToSection(sectionId: string): void {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  }

  // Helper function to dynamically create Tailwind classes
  getBgColor(color: string): string {
    return `bg-${color}-600`;
  }

  getTextColor(color: string): string {
    return `text-${color}-600`;
  }
  
  getHoverBgColor(color: string): string {
    return `hover:bg-${color}-700`;
  }

  getBorderColor(color: string): string {
    return `border-${color}-500`;
  }
}
